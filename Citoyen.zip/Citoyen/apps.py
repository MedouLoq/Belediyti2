from django.apps import AppConfig


class CitoyenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Citoyen'
