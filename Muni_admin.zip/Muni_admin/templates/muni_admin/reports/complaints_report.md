# Rapport des Réclamations

**Municipalité:** {{ municipality.name }}  
**Période:** {% if date_from %}{{ date_from }}{% else %}Début{% endif %} - {% if date_to %}{{ date_to }}{% else %}{{ generated_at|date:"Y-m-d" }}{% endif %}  
**Généré le:** {{ generated_at|date:"d/m/Y à H:i" }}  
**Généré par:** {{ generated_by }}

---

## Résumé Exécutif

Ce rapport présente une analyse complète des réclamations reçues par la municipalité de {{ municipality.name }}{% if date_from or date_to %} pour la période du {% if date_from %}{{ date_from }}{% else %}début{% endif %} au {% if date_to %}{{ date_to }}{% else %}{{ generated_at|date:"d/m/Y" }}{% endif %}{% endif %}.

### Statistiques Principales

- **Total des réclamations:** {{ total_complaints }}
- **Temps moyen de résolution:** {% if avg_resolution_time %}{{ avg_resolution_time|floatformat:1 }} jours{% else %}Non disponible{% endif %}

## Répartition par Statut

{% for status in status_breakdown %}
- **{{ status.status }}:** {{ status.count }} réclamation{{ status.count|pluralize }}
{% endfor %}

{% if include_details and complaints %}
## Détails des Réclamations

{% for complaint in complaints %}
### Réclamation #{{ complaint.id|slice:":8" }}

- **Sujet:** {{ complaint.subject }}
- **Description:** {{ complaint.description }}
- **Statut:** {{ complaint.get_status_display }}
- **Citoyen:** {{ complaint.citizen.full_name }}
- **Date de création:** {{ complaint.created_at|date:"d/m/Y H:i" }}
- **Dernière mise à jour:** {{ complaint.updated_at|date:"d/m/Y H:i" }}

---
{% endfor %}
{% endif %}

## Analyse des Tendances

### Types de Réclamations les Plus Fréquents
1. Demandes de documents administratifs
2. Réclamations sur les services publics
3. Demandes d'information

### Recommandations

1. **Digitalisation des services:** Mettre en place des services en ligne pour réduire les réclamations administratives.
2. **Amélioration de la communication:** Développer des canaux de communication plus efficaces.
3. **Formation du personnel:** Améliorer la qualité du service client.

---

*Rapport généré automatiquement par le système de gestion municipale*

