# Rapport des Problèmes

**Municipalité:** {{ municipality.name }}  
**Période:** {% if date_from %}{{ date_from }}{% else %}Début{% endif %} - {% if date_to %}{{ date_to }}{% else %}{{ generated_at|date:"Y-m-d" }}{% endif %}  
**Généré le:** {{ generated_at|date:"d/m/Y à H:i" }}  
**Généré par:** {{ generated_by }}

---

## Résumé Exécutif

Ce rapport présente une analyse détaillée des problèmes signalés dans la municipalité de {{ municipality.name }}{% if date_from or date_to %} pour la période du {% if date_from %}{{ date_from }}{% else %}début{% endif %} au {% if date_to %}{{ date_to }}{% else %}{{ generated_at|date:"d/m/Y" }}{% endif %}{% endif %}.

### Statistiques Principales

- **Total des problèmes:** {{ total_problems }}
- **Temps moyen de résolution:** {% if avg_resolution_time %}{{ avg_resolution_time|floatformat:1 }} jours{% else %}Non disponible{% endif %}

## Répartition par Statut

{% for status in status_breakdown %}
- **{{ status.status }}:** {{ status.count }} problème{{ status.count|pluralize }}
{% endfor %}

## Répartition par Catégorie

{% for category in category_breakdown %}
- **{{ category.category__name|default:"Non catégorisé" }}:** {{ category.count }} problème{{ category.count|pluralize }}
{% endfor %}

{% if include_details and problems %}
## Détails des Problèmes

{% for problem in problems %}
### Problème #{{ problem.id|slice:":8" }}

- **Description:** {{ problem.description }}
- **Catégorie:** {{ problem.category.name|default:"Non catégorisé" }}
- **Statut:** {{ problem.get_status_display }}
- **Citoyen:** {{ problem.citizen.full_name }}
- **Localisation:** {{ problem.location|default:"Non spécifiée" }}
- **Date de création:** {{ problem.created_at|date:"d/m/Y H:i" }}
- **Dernière mise à jour:** {{ problem.updated_at|date:"d/m/Y H:i" }}

---
{% endfor %}
{% endif %}

## Recommandations

1. **Amélioration des délais de traitement:** Mettre en place des procédures pour réduire le temps moyen de résolution.
2. **Formation du personnel:** Organiser des formations pour améliorer l'efficacité du traitement des problèmes.
3. **Communication avec les citoyens:** Améliorer la communication sur l'avancement des dossiers.

---

*Rapport généré automatiquement par le système de gestion municipale*

