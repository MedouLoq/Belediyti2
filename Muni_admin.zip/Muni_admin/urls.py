# Muni_admin/urls.py
from django.urls import path
from . import views

app_name = 'Muni_admin'

urlpatterns = [
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    
    # Problems
    path('problems/', views.problem_list, name='problems'),
    path('problems/<uuid:problem_id>/detail/', views.problem_detail, name='problem_detail'),
    
    # Complaints
    path('complaints/', views.complaint_list, name='complaints'),
    path('complaints/<uuid:complaint_id>/', views.complaint_detail, name='complaint_detail'),
    
    # Settings and Profile
    path('settings/', views.settings, name='settings'),
    path('profile/', views.profile, name='profile'),
    
    # Reports
    path('reports/', views.reports, name='reports'),
    path('reports/generate/', views.generate_report, name='generate_report'),
]

