from django.apps import AppConfig


class MuniAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Muni_admin'
    label = 'muni_admin'
