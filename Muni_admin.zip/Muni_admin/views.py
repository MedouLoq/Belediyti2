from django.shortcuts import render

# Create your views here.
def admin_home(request):
    return render(request,'muni_admin/base.html')

from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.utils.translation import gettext as _
from django.db.models import Q, Count
from Citoyen.models import Problem,Category #Import model is core class value dispatcher name

ITEMS_PER_PAGE = 10 #You can set list value

@login_required #if value name login check view dispatcher access  for not name access
def problem_list(request):
    user_municipality = request.user.admin_profile.municipality #user by session name in model with one filter to view list is user

    search_term = request.GET.get('search', '')#dispatch all filter with names
    status_filter = request.GET.get('status', '')  #dispatch all class
    category_filter = request.GET.get('category', '')

    problems = Problem.objects.filter(municipality=user_municipality)#Load models by municipality code list

    # Apply filters
    if search_term:
         problems = problems.filter(Q(description__icontains=search_term) | #number dispatcher user in page if
                                  Q(location__icontains=search_term))# check values text

        #If used this list, be check user if it's a superadmin
    if status_filter:
        problems = problems.filter(status=status_filter)

    if category_filter:
        problems = problems.filter(category_id=category_filter)


    # Pagination use in load last line
    paginator = Paginator(problems, ITEMS_PER_PAGE)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)


    # all new name to load template list by name in order
    context = {
        'problems': page_obj,
        'search_term': search_term,  # value  filter text dispatcher number

       'status_filter': status_filter, #dispatcher name chart

        'category_filter': category_filter,# if used set code values
        'categories': Category.objects.all(),#select option id name function list
        'status_choices': Problem.STATUS_CHOICES,  #model list for select dropdownMenu  class options value
         #all names and dispatcher for template list class, and dispatcher function list
    }

    return render(request, 'muni_admin/problem_list.html', context)
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db.models import Count, Avg, F, ExpressionWrapper, fields, Q
from django.core import serializers
from Citoyen.models import Problem, Complaint, Category, StatusLog
import datetime
from collections import defaultdict
import json

@login_required
def dashboard(request):
    municipality = request.user.admin_profile.municipality
    
    # Get period parameter (default: 7 days)
    days_period = int(request.GET.get('days', 7))
    today = timezone.now().date()
    period_start = today - datetime.timedelta(days=days_period)
    previous_period_start = period_start - datetime.timedelta(days=days_period)
    
    # Basic counts
    total_problems = Problem.objects.filter(municipality=municipality).count()
    new_problems_last_period = Problem.objects.filter(
        municipality=municipality, 
        created_at__date__gte=period_start
    ).count()
    
    # Compare with previous period
    problems_previous_period = Problem.objects.filter(
        municipality=municipality,
        created_at__date__gte=previous_period_start,
        created_at__date__lt=period_start
    ).count()
    
    # Calculate percent change
    problem_percent_change = 0
    if problems_previous_period > 0:
        problem_percent_change = round(((new_problems_last_period - problems_previous_period) / problems_previous_period) * 100)
    
    # Same for complaints
    total_complaints = Complaint.objects.filter(municipality=municipality).count()
    new_complaints_last_period = Complaint.objects.filter(
        municipality=municipality, 
        created_at__date__gte=period_start
    ).count()
    
    complaints_previous_period = Complaint.objects.filter(
        municipality=municipality,
        created_at__date__gte=previous_period_start,
        created_at__date__lt=period_start
    ).count()
    
    complaint_percent_change = 0
    if complaints_previous_period > 0:
        complaint_percent_change = round(((new_complaints_last_period - complaints_previous_period) / complaints_previous_period) * 100)
    
    # New problems percent change
    new_problem_percent_change = 0
    if problems_previous_period > 0:
        new_problem_percent_change = round(((new_problems_last_period - problems_previous_period) / problems_previous_period) * 100)
    
    # New complaints percent change
    new_complaint_percent_change = 0
    if complaints_previous_period > 0:
        new_complaint_percent_change = round(((new_complaints_last_period - complaints_previous_period) / complaints_previous_period) * 100)
    
    # Status breakdown for problems
    problem_status_data = Problem.objects.filter(
        municipality=municipality
    ).values('status').annotate(count=Count('status'))
    
    # Status breakdown for complaints
    complaint_status_data = Complaint.objects.filter(
        municipality=municipality
    ).values('status').annotate(count=Count('status'))
    
    # Top problem categories
    problem_categories_data = Problem.objects.filter(
        municipality=municipality
    ).values('category__name').annotate(
        count=Count('category')
    ).order_by('-count')[:5]
    
    # Problem and complaint time series data (for the charts)
    # Get data for last X days
    time_series_days = 90  # Show data for last 90 days
    time_series_start = today - datetime.timedelta(days=time_series_days)
    
    # Generate date range
    date_range = []
    current_date = time_series_start
    while current_date <= today:
        date_range.append(current_date)
        current_date += datetime.timedelta(days=1)
    
    # Problems by day
    problems_by_day = Problem.objects.filter(
        municipality=municipality, 
        created_at__date__gte=time_series_start
    ).annotate(
        created_day=ExpressionWrapper(
            F('created_at__date'), 
            output_field=fields.DateField()
        )
    ).values('created_day').annotate(
        count=Count('id')
    ).order_by('created_day')
    
    # Convert to dictionary for easier lookup
    problems_data = defaultdict(int)
    for item in problems_by_day:
        problems_data[item['created_day'].strftime('%Y-%m-%d')] = item['count']
    
    # Complaints by day
    complaints_by_day = Complaint.objects.filter(
        municipality=municipality, 
        created_at__date__gte=time_series_start
    ).annotate(
        created_day=ExpressionWrapper(
            F('created_at__date'), 
            output_field=fields.DateField()
        )
    ).values('created_day').annotate(
        count=Count('id')
    ).order_by('created_day')
    
    complaints_data = defaultdict(int)
    for item in complaints_by_day:
        complaints_data[item['created_day'].strftime('%Y-%m-%d')] = item['count']
    
    # Prepare time series data for charts
    problems_time_series = {
        'dates': [d.strftime('%Y-%m-%d') for d in date_range],
        'series': [{
            'name': 'Problèmes',
            'data': [problems_data.get(d.strftime('%Y-%m-%d'), 0) for d in date_range]
        }]
    }
    
    complaints_time_series = {
        'dates': [d.strftime('%Y-%m-%d') for d in date_range],
        'series': [{
            'name': 'Réclamations',
            'data': [complaints_data.get(d.strftime('%Y-%m-%d'), 0) for d in date_range]
        }]
    }
    
    # Resolution time data
    # Calculate average time to resolve by category
    # First, get problems that have been resolved
    resolved_problems = Problem.objects.filter(
        municipality=municipality,
        status='RESOLVED'
    )
    
    # Group them by category and calculate average resolution time
    resolution_time_data = []
    
    # Get status logs for resolved problems
    if resolved_problems.exists():
        status_logs = StatusLog.objects.filter(
            record_type='PROBLEM',
            record_id__in=resolved_problems.values_list('id', flat=True),
            new_status='RESOLVED'
        )
        
        # Group by category
        category_resolution_times = defaultdict(list)
        
        for problem in resolved_problems:
            # Find the log entry where this problem was resolved
            log_entry = status_logs.filter(record_id=problem.id).first()
            
            if log_entry:
                # Calculate time difference in days
                resolution_time = (log_entry.changed_at.date() - problem.created_at.date()).days
                category_name = problem.category.name if problem.category else 'Sans catégorie'
                category_resolution_times[category_name].append(resolution_time)
        
        # Calculate averages
        for category, times in category_resolution_times.items():
            if times:
                avg_days = sum(times) / len(times)
                resolution_time_data.append({
                    'category': category,
                    'avg_days': avg_days
                })
    
    # Sort by average resolution time (ascending)
    resolution_time_data.sort(key=lambda x: x['avg_days'])
    
    # Get problem locations for the map
    problem_map_data = Problem.objects.filter(
        municipality=municipality
    ).select_related('category').values(
        'pk', 'latitude', 'longitude', 'description', 'status', 
        'created_at', 'category__name'
    )
    
    # Enhanced recent activities with more detail
    recent_activities = []
    
    # Recent problems with more detailed info
    recent_problems = Problem.objects.filter(
        municipality=municipality
    ).select_related('category', 'citizen').order_by('-created_at')[:10]
    
    for problem in recent_problems:
        status_display = dict(Problem.STATUS_CHOICES).get(problem.status, problem.status)
        detail_url = f"/admin/problems/{problem.id}/detail/"
        
        recent_activities.append({
            'type': 'problem',
            'text': f"Problème signalé: {problem.description[:50]}...",
            'timestamp': problem.created_at,
            'status': problem.status,
            'status_display': status_display,
            'detail_url': detail_url
        })
    
    # Recent complaints with more detailed info
    recent_complaints = Complaint.objects.filter(
        municipality=municipality
    ).select_related('citizen').order_by('-created_at')[:10]
    
    for complaint in recent_complaints:
        status_display = dict(Complaint.STATUS_CHOICES).get(complaint.status, complaint.status)
        detail_url = f"/admin/complaints/{complaint.id}/detail/"
        
        recent_activities.append({
            'type': 'complaint',
            'text': f"Réclamation soumise: {complaint.subject[:50]}...",
            'timestamp': complaint.created_at,
            'status': complaint.status,
            'status_display': status_display,
            'detail_url': detail_url
        })
    
    # Sort recent activities by timestamp
    recent_activities = sorted(recent_activities, key=lambda x: x['timestamp'], reverse=True)[:15]
    
    # Serialize data for JavaScript
    problem_status_data_dump = json.dumps(list(problem_status_data))
    complaint_status_data_dump = json.dumps(list(complaint_status_data))
    problem_categories_data_dump = json.dumps( list(problem_categories_data))
    problem_map_data_dump = json.dumps(list(problem_map_data), default=str)
    
    # Context for the template
    context = {
        'total_problems': total_problems,
        'new_problems_last_7_days': new_problems_last_period,
        'problem_percent_change': problem_percent_change,
        'new_problem_percent_change': new_problem_percent_change,
        
        'total_complaints': total_complaints,
        'new_complaints_last_7_days': new_complaints_last_period,
        'complaint_percent_change': complaint_percent_change,
        'new_complaint_percent_change': new_complaint_percent_change,
        
        'problem_status_data': problem_status_data_dump,
        'complaint_status_data': complaint_status_data_dump,
        'problem_categories_data': problem_categories_data_dump,
        'problems_time_series': json.dumps(problems_time_series),
        'complaints_time_series': json.dumps(complaints_time_series),
        'resolution_time_data': json.dumps(resolution_time_data),
        'problem_map_data': problem_map_data_dump,
        
        'recent_activities': recent_activities,
        'municipality': municipality,
        'navName': 'dashboard',
    }
    
    return render(request, 'muni_admin/dashboard.html', context)


from django.shortcuts import get_object_or_404
from Citoyen.models import Problem, StatusLog # Assuming models are in Citoyen app
from Citoyen.models import Notification
@login_required
def problem_detail(request, problem_id):
    # Fetch the specific problem, ensuring it belongs to the admin's municipality (or handle superadmin case)
    problem = get_object_or_404(Problem.objects.select_related(
        'citizen', 'category', 'municipality'
    ), pk=problem_id, municipality=request.user.admin_profile.municipality)
    
    # Fetch status change history for this problem
    status_logs = StatusLog.objects.filter(
        record_type='PROBLEM', 
        record_id=problem.id
    ).order_by('-changed_at').select_related('changed_by')
    
    # Handle status update form submission
    if request.method == 'POST':
        old_status = problem.status
        new_status = request.POST.get('status')
        comment = request.POST.get('comment', '')
        
        if new_status and new_status != old_status:
            # Update problem status
            problem.status = new_status
            problem.comment = comment
            problem.save()
            
            # Create status log entry
            StatusLog.objects.create(
                record_type='PROBLEM',
                record_id=problem.id,
                old_status=old_status,
                new_status=new_status,
                changed_by=request.user,
                changed_at=timezone.now()
            )
            
            # Optional: Create notification for the citizen
            Notification.objects.create(
                user=problem.citizen.user,
                title=_("Mise à jour de votre signalement"),
                message=_("Le statut de votre problème a été mis à jour à: {}").format(
                    dict(Problem.STATUS_CHOICES)[new_status]
                ),
                type='PROBLEM_UPDATE',
                related_id=str(problem.id),
                related_type='PROBLEM'
            )
            
            # Add success message
            from django.contrib import messages
            messages.success(request, _("Statut mis à jour avec succès."))
            
            # Redirect to avoid form resubmission
            from django.shortcuts import redirect
            return redirect('Muni_admin:problem_detail', problem_id=problem_id)
    
    # Prepare context for the template
    context = {
        'problem': problem,
        'status_logs': status_logs,
        'status_choices': Problem.STATUS_CHOICES,  # Pass status choices for potential status change form
        'navName': 'problems',  # For navigation highlighting
    }
    
    return render(request, 'muni_admin/problem_detail.html', context)



# Complaint Views
@login_required
def complaint_list(request):
    user_municipality = request.user.admin_profile.municipality

    search_term = request.GET.get('search', '')
    status_filter = request.GET.get('status', '')

    complaints = Complaint.objects.filter(municipality=user_municipality)

    # Apply filters
    if search_term:
        complaints = complaints.filter(Q(subject__icontains=search_term) | 
                                     Q(description__icontains=search_term))

    if status_filter:
        complaints = complaints.filter(status=status_filter)

    # Pagination
    paginator = Paginator(complaints, ITEMS_PER_PAGE)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'complaints': page_obj,
        'search_term': search_term,
        'status_filter': status_filter,
        'status_choices': Complaint.STATUS_CHOICES,
        'navName': 'complaints',
    }

    return render(request, 'muni_admin/complaint_list.html', context)

@login_required
def complaint_detail(request, complaint_id):
    complaint = get_object_or_404(Complaint.objects.select_related(
        'citizen', 'municipality'
    ), pk=complaint_id, municipality=request.user.admin_profile.municipality)
    
    # Fetch status change history for this complaint
    status_logs = StatusLog.objects.filter(
        record_type='COMPLAINT', 
        record_id=complaint.id
    ).order_by('-changed_at').select_related('changed_by')
    
    # Handle status update form submission
    if request.method == 'POST':
        old_status = complaint.status
        new_status = request.POST.get('status')
        comment = request.POST.get('comment', '')
        
        if new_status and new_status != old_status:
            # Update complaint status
            complaint.status = new_status
            complaint.comment = comment
            complaint.save()
            
            # Create status log entry
            StatusLog.objects.create(
                record_type='COMPLAINT',
                record_id=complaint.id,
                old_status=old_status,
                new_status=new_status,
                changed_by=request.user,
                changed_at=timezone.now()
            )
            
            # Create notification for the citizen
            Notification.objects.create(
                user=complaint.citizen.user,
                title=_("Mise à jour de votre réclamation"),
                message=_("Le statut de votre réclamation a été mis à jour à: {}").format(
                    dict(Complaint.STATUS_CHOICES)[new_status]
                ),
                type='COMPLAINT_UPDATE',
                related_id=str(complaint.id),
                related_type='COMPLAINT'
            )
            
            # Add success message
            from django.contrib import messages
            messages.success(request, _("Statut mis à jour avec succès."))
            
            # Redirect to avoid form resubmission
            from django.shortcuts import redirect
            return redirect('Muni_admin:complaint_detail', complaint_id=complaint_id)
    
    context = {
        'complaint': complaint,
        'status_logs': status_logs,
        'status_choices': Complaint.STATUS_CHOICES,
        'navName': 'complaints',
    }
    
    return render(request, 'muni_admin/complaint_detail.html', context)

@login_required
def settings(request):
    context = {
        'navName': 'settings',
    }
    return render(request, 'muni_admin/settings.html', context)

@login_required
def profile(request):
    context = {
        'navName': 'profile',
    }
    return render(request, 'muni_admin/profile.html', context)


# Report Generation Views
from django.http import HttpResponse
from django.template.loader import render_to_string
import json
import csv
from datetime import  timedelta
from django.db.models import Count, Avg, Q
from django.utils import timezone

@login_required
def reports(request):
    """Main reports page with report generation options"""
    municipality = request.user.admin_profile.municipality
    
    # Get basic statistics for the reports page
    total_problems = Problem.objects.filter(municipality=municipality).count()
    total_complaints = Complaint.objects.filter(municipality=municipality).count()
    
    # Recent activity for quick stats
    last_30_days = timezone.now() - timedelta(days=30)
    recent_problems = Problem.objects.filter(
        municipality=municipality, 
        created_at__gte=last_30_days
    ).count()
    recent_complaints = Complaint.objects.filter(
        municipality=municipality, 
        created_at__gte=last_30_days
    ).count()
    
    context = {
        'total_problems': total_problems,
        'total_complaints': total_complaints,
        'recent_problems': recent_problems,
        'recent_complaints': recent_complaints,
        'categories': Category.objects.all(),
        'navName': 'reports',
    }
    
    return render(request, 'muni_admin/reports.html', context)

@login_required
def generate_report(request):
    """Generate reports based on user selection"""
    if request.method == 'POST':
        municipality = request.user.admin_profile.municipality
        
        # Get form data
        report_type = request.POST.get('report_type')
        date_from = request.POST.get('date_from')
        date_to = request.POST.get('date_to')
        format_type = request.POST.get('format', 'pdf')
        include_charts = request.POST.get('include_charts') == 'on'
        include_details = request.POST.get('include_details') == 'on'
        
        # Parse dates
        try:
            if date_from:
                date_from = datetime.strptime(date_from, '%Y-%m-%d').date()
            if date_to:
                date_to = datetime.strptime(date_to, '%Y-%m-%d').date()
        except ValueError:
            messages.error(request, "Format de date invalide.")
            return redirect('Muni_admin:reports')
        
        # Generate report data based on type
        if report_type == 'problems':
            return generate_problems_report(request, municipality, date_from, date_to, format_type, include_charts, include_details)
        elif report_type == 'complaints':
            return generate_complaints_report(request, municipality, date_from, date_to, format_type, include_charts, include_details)
        elif report_type == 'summary':
            return generate_summary_report(request, municipality, date_from, date_to, format_type, include_charts, include_details)
        elif report_type == 'performance':
            return generate_performance_report(request, municipality, date_from, date_to, format_type, include_charts, include_details)
    
    return redirect('Muni_admin:reports')

def generate_problems_report(request, municipality, date_from, date_to, format_type, include_charts, include_details):
    """Generate problems report"""
    # Filter problems
    problems = Problem.objects.filter(municipality=municipality)
    if date_from:
        problems = problems.filter(created_at__date__gte=date_from)
    if date_to:
        problems = problems.filter(created_at__date__lte=date_to)
    
    # Statistics
    total_problems = problems.count()
    status_breakdown = problems.values('status').annotate(count=Count('status'))
    category_breakdown = problems.values('category__name').annotate(count=Count('category'))
    
    # Resolution time analysis
    resolved_problems = problems.filter(status='RESOLVED')
    avg_resolution_time = None
    if resolved_problems.exists():
        resolution_times = []
        for problem in resolved_problems:
            status_log = StatusLog.objects.filter(
                record_type='PROBLEM',
                record_id=problem.id,
                new_status='RESOLVED'
            ).first()
            if status_log:
                resolution_time = (status_log.changed_at.date() - problem.created_at.date()).days
                resolution_times.append(resolution_time)
        
        if resolution_times:
            avg_resolution_time = sum(resolution_times) / len(resolution_times)
    
    # Prepare context
    context = {
        'report_title': 'Rapport des Problèmes',
        'municipality': municipality,
        'date_from': date_from,
        'date_to': date_to,
        'total_problems': total_problems,
        'status_breakdown': list(status_breakdown),
        'category_breakdown': list(category_breakdown),
        'avg_resolution_time': avg_resolution_time,
        'problems': problems[:100] if include_details else None,  # Limit for performance
        'include_charts': include_charts,
        'include_details': include_details,
        'generated_at': timezone.now(),
        'generated_by': request.user.username,
    }
    
    if format_type == 'pdf':
        return generate_pdf_report(context, 'problems_report')
    elif format_type == 'csv':
        return generate_csv_report(problems, 'problems_report')
    else:
        return generate_html_report(context, 'muni_admin/reports/problems_report.html')

def generate_complaints_report(request, municipality, date_from, date_to, format_type, include_charts, include_details):
    """Generate complaints report"""
    # Filter complaints
    complaints = Complaint.objects.filter(municipality=municipality)
    if date_from:
        complaints = complaints.filter(created_at__date__gte=date_from)
    if date_to:
        complaints = complaints.filter(created_at__date__lte=date_to)
    
    # Statistics
    total_complaints = complaints.count()
    status_breakdown = complaints.values('status').annotate(count=Count('status'))
    
    # Resolution time analysis
    resolved_complaints = complaints.filter(status='RESOLVED')
    avg_resolution_time = None
    if resolved_complaints.exists():
        resolution_times = []
        for complaint in resolved_complaints:
            status_log = StatusLog.objects.filter(
                record_type='COMPLAINT',
                record_id=complaint.id,
                new_status='RESOLVED'
            ).first()
            if status_log:
                resolution_time = (status_log.changed_at.date() - complaint.created_at.date()).days
                resolution_times.append(resolution_time)
        
        if resolution_times:
            avg_resolution_time = sum(resolution_times) / len(resolution_times)
    
    context = {
        'report_title': 'Rapport des Réclamations',
        'municipality': municipality,
        'date_from': date_from,
        'date_to': date_to,
        'total_complaints': total_complaints,
        'status_breakdown': list(status_breakdown),
        'avg_resolution_time': avg_resolution_time,
        'complaints': complaints[:100] if include_details else None,
        'include_charts': include_charts,
        'include_details': include_details,
        'generated_at': timezone.now(),
        'generated_by': request.user.username,
    }
    
    if format_type == 'pdf':
        return generate_pdf_report(context, 'complaints_report')
    elif format_type == 'csv':
        return generate_csv_report(complaints, 'complaints_report')
    else:
        return generate_html_report(context, 'muni_admin/reports/complaints_report.html')

def generate_summary_report(request, municipality, date_from, date_to, format_type, include_charts, include_details):
    """Generate summary report with both problems and complaints"""
    # Filter data
    problems = Problem.objects.filter(municipality=municipality)
    complaints = Complaint.objects.filter(municipality=municipality)
    
    if date_from:
        problems = problems.filter(created_at__date__gte=date_from)
        complaints = complaints.filter(created_at__date__gte=date_from)
    if date_to:
        problems = problems.filter(created_at__date__lte=date_to)
        complaints = complaints.filter(created_at__date__lte=date_to)
    
    # Combined statistics
    total_issues = problems.count() + complaints.count()
    problem_status_breakdown = problems.values('status').annotate(count=Count('status'))
    complaint_status_breakdown = complaints.values('status').annotate(count=Count('status'))
    
    context = {
        'report_title': 'Rapport de Synthèse',
        'municipality': municipality,
        'date_from': date_from,
        'date_to': date_to,
        'total_problems': problems.count(),
        'total_complaints': complaints.count(),
        'total_issues': total_issues,
        'problem_status_breakdown': list(problem_status_breakdown),
        'complaint_status_breakdown': list(complaint_status_breakdown),
        'include_charts': include_charts,
        'include_details': include_details,
        'generated_at': timezone.now(),
        'generated_by': request.user.username,
    }
    
    if format_type == 'pdf':
        return generate_pdf_report(context, 'summary_report')
    else:
        return generate_html_report(context, 'muni_admin/reports/summary_report.html')

def generate_performance_report(request, municipality, date_from, date_to, format_type, include_charts, include_details):
    """Generate performance analysis report"""
    # Get data for performance analysis
    problems = Problem.objects.filter(municipality=municipality)
    complaints = Complaint.objects.filter(municipality=municipality)
    
    if date_from:
        problems = problems.filter(created_at__date__gte=date_from)
        complaints = complaints.filter(created_at__date__gte=date_from)
    if date_to:
        problems = problems.filter(created_at__date__lte=date_to)
        complaints = complaints.filter(created_at__date__lte=date_to)
    
    # Performance metrics
    total_resolved_problems = problems.filter(status='RESOLVED').count()
    total_resolved_complaints = complaints.filter(status='RESOLVED').count()
    
    problem_resolution_rate = (total_resolved_problems / problems.count() * 100) if problems.count() > 0 else 0
    complaint_resolution_rate = (total_resolved_complaints / complaints.count() * 100) if complaints.count() > 0 else 0
    
    # Average response time (time to first status change)
    avg_response_time_problems = calculate_avg_response_time(problems, 'PROBLEM')
    avg_response_time_complaints = calculate_avg_response_time(complaints, 'COMPLAINT')
    
    context = {
        'report_title': 'Rapport de Performance',
        'municipality': municipality,
        'date_from': date_from,
        'date_to': date_to,
        'total_problems': problems.count(),
        'total_complaints': complaints.count(),
        'total_resolved_problems': total_resolved_problems,
        'total_resolved_complaints': total_resolved_complaints,
        'problem_resolution_rate': round(problem_resolution_rate, 2),
        'complaint_resolution_rate': round(complaint_resolution_rate, 2),
        'avg_response_time_problems': avg_response_time_problems,
        'avg_response_time_complaints': avg_response_time_complaints,
        'include_charts': include_charts,
        'include_details': include_details,
        'generated_at': timezone.now(),
        'generated_by': request.user.username,
    }
    
    if format_type == 'pdf':
        return generate_pdf_report(context, 'performance_report')
    else:
        return generate_html_report(context, 'muni_admin/reports/performance_report.html')

def calculate_avg_response_time(queryset, record_type):
    """Calculate average response time for issues"""
    response_times = []
    for item in queryset:
        first_status_change = StatusLog.objects.filter(
            record_type=record_type,
            record_id=item.id
        ).order_by('changed_at').first()
        
        if first_status_change:
            response_time = (first_status_change.changed_at.date() - item.created_at.date()).days
            response_times.append(response_time)
    
    return sum(response_times) / len(response_times) if response_times else 0

def generate_pdf_report(context, template_name):
    """Generate PDF report using markdown and manus-md-to-pdf"""
    import tempfile
    import os
    
    # Create markdown content
    md_content = render_to_string(f'muni_admin/reports/{template_name}.md', context)
    
    # Create temporary files
    with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as md_file:
        md_file.write(md_content)
        md_file_path = md_file.name
    
    pdf_file_path = md_file_path.replace('.md', '.pdf')
    
    try:
        # Use manus-md-to-pdf utility
        import subprocess
        result = subprocess.run(['manus-md-to-pdf', md_file_path, pdf_file_path], 
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            # Read PDF file and return as response
            with open(pdf_file_path, 'rb') as pdf_file:
                response = HttpResponse(pdf_file.read(), content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="{template_name}_{timezone.now().strftime("%Y%m%d_%H%M%S")}.pdf"'
                return response
        else:
            messages.error(request, f"Erreur lors de la génération du PDF: {result.stderr}")
            return redirect('Muni_admin:reports')
    
    finally:
        # Clean up temporary files
        if os.path.exists(md_file_path):
            os.unlink(md_file_path)
        if os.path.exists(pdf_file_path):
            os.unlink(pdf_file_path)

def generate_csv_report(queryset, filename):
    """Generate CSV report"""
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{filename}_{timezone.now().strftime("%Y%m%d_%H%M%S")}.csv"'
    
    writer = csv.writer(response)
    
    # Determine model type and write appropriate headers
    if queryset.model == Problem:
        writer.writerow(['ID', 'Description', 'Catégorie', 'Statut', 'Citoyen', 'Localisation', 'Date de création', 'Dernière mise à jour'])
        for problem in queryset:
            writer.writerow([
                str(problem.id)[:8],
                problem.description,
                problem.category.name if problem.category else 'N/A',
                problem.get_status_display(),
                problem.citizen.full_name,
                problem.location or 'N/A',
                problem.created_at.strftime('%Y-%m-%d %H:%M'),
                problem.updated_at.strftime('%Y-%m-%d %H:%M')
            ])
    elif queryset.model == Complaint:
        writer.writerow(['ID', 'Sujet', 'Description', 'Statut', 'Citoyen', 'Date de création', 'Dernière mise à jour'])
        for complaint in queryset:
            writer.writerow([
                str(complaint.id)[:8],
                complaint.subject,
                complaint.description,
                complaint.get_status_display(),
                complaint.citizen.full_name,
                complaint.created_at.strftime('%Y-%m-%d %H:%M'),
                complaint.updated_at.strftime('%Y-%m-%d %H:%M')
            ])
    
    return response

def generate_html_report(request,context, template_path):
    """Generate HTML report for preview"""
    return render(request, template_path, context)

